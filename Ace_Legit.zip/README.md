# Aces_Semi_CFG

Semi-Rage CFG<br/>
Aimbot <br/>
L FOV 15 <br/>
L Smoothing 0 <br/>
L Triggerbot set to 0 min dmg. To hit anything no matter what. If you want HS only set it to 100 <br/>
ESP <br/>
L All Red <br/>
L Through walls <br/>
L Mix of Textured for Vis + Flat for Invis <br/>
L Player's arms are gone and gun is red <br/>
Misc <br/>
L Unsafe features on <br/>
L Bhop features on <br/>

CHECK KEYBINDS ❤️ <br/>

LOCATION: C:\Users\PCNAME\AppData\Roaming\INTERIUM\CS2\configs

![Screenshot 2025-02-04 202142](https://github.com/user-attachments/assets/ecdca796-db27-4874-be84-4865ab46b5bb)
